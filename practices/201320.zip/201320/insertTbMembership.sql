
insert into Membership(membership_id,membership_name
,membership_lastname,membership_number,membership_due,membership_date)
values(1,'Elizabeth','Bishop','36736-36738',976.063,'02/08/1911');

insert into Membership(membership_id,membership_name
,membership_lastname,membership_number,membership_due,membership_date)
values(2,'Charles','Dickens','36734-5461',2244.789,'07/02/1812');

insert into Membership(membership_id,membership_name
,membership_lastname,membership_number,membership_due,membership_date)
values(3,'Jack','London','5462-37314',898.127,'12/01/1876');

insert into Membership(membership_id,membership_name
,membership_lastname,membership_number,membership_due,membership_date)
values(4,'Joseph','Conrad','37315-5463',1193.493,'03/12/1857');

insert into Membership(membership_id,membership_name
,membership_lastname,membership_number,membership_due,membership_date)
values(5,'Gustave','Flaubert','37313-37316',1435.384,'12/12/1821');

insert into Membership(membership_id,membership_name
,membership_lastname,membership_number,membership_due,membership_date)
values(6,'John','Milton','37317-37296',1348.582,'9/12/1608');